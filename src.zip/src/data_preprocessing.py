import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder
import matplotlib.pyplot as plt
import seaborn as sns

raw_data_path = r"D:\My projects\carrier-sla-risk-intelligence-model\data\raw\b2b_sla_logistics_dataset_200k.csv"
processed_data_path = r"D:\My projects\carrier-sla-risk-intelligence-model\data\processed\week1_cleaned_data.csv"

# ===============================================================
# Helpter Functions
# ===============================================================

def load_data(filepath):
    """Loads the raw dataset."""
    print(f"Loading data from {filepath}...")
    return pd.read_csv(filepath, low_memory=False)

def create_target_variable(df):
    """Creates the target column 'sla_breach_flag'.
    Logic: 1 if actual_delivery_days > planned_delivery_days, else 0
    """
    df["sla_breach_flag"] = np.where(
        df["actual_delivery_days"] > df["planned_delivery_days"], 1, 0
    )
    return df
if __name__ == "__main__":
    df = load_data(raw_data_path)

    df = create_target_variable(df)
  


